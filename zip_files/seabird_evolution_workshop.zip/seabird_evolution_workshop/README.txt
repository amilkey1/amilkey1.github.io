This lesson on seabird evolution is designed as follows:
1. Students color in the birds.
2. Students fill out the character trait matrix, using the "bird facts" page.
3. Students cut out the birds and paste them onto the cladograms.
4. Students add traits to the cladogram.
5. Students discuss the bonus questions with a parent, friend, or teacher.

The lesson was designed for a wide range of ages at a local public library.
Younger students can just color the birds and fill out the character matrix, while older students can complete the entire activity.